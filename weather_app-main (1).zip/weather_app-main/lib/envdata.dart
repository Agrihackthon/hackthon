const weatherapikey = '5a1139a980e31152039d863a204837be';



// API Key for OpenWeatherMap.org

// af94be930f5f70acc2d1b12cd8d5e88e
// b67e5c684bd7777f9685d7dccb1559e7
// 880800201440af9e6b4de3808c0d510c